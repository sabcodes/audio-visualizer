# BENCHMARK: is the system good enough to drop a director checkpoint?

Two measurements: the ASSET score (did the build get good?) and the SYSTEM
score (how much a strong director had to do). A checkpoint moves to a lighter
model only when both hold.

## 1. Asset scorecard (fill in per asset, per final round)

| metric | how measured | skeleton v4 (to date) | dragon v1 (P2) |
|---|---|---|
| Likeness IoU at the reference view | likeness.py, chest-relative window, props ignored | 0.5734 (v4.4 final; base 0.4766) | 0.7787 final (P2 0.7077) |
| Max IK error to the lifted targets | pose report | 0.0135 m | chains 0.0006 m, branch 0.098 m, fingers 0.005 m (P2b, 77-joint rig) |
| pose_lift flags unexplained | pose_lift on the final lengths | 0 (1 at 0.5%, noise) |
| Form checklist yes / total | R5 table + form gates | builder 6/6; director 4/6 (scapula visible from one 3/4 side; ribs uniform rods) |
| QA gates passed / total | validate, eval_glb_v32, programmatic, pose, previews | 6/6 (v4.4) |
| Tris within the budget | eval | 34,434 / 35,000 (v4.4) | 34,784 / 35,000 (P2c) |
| Face dark-feature IoU | face_features.py at the FIXED face view (v1.7 rule) | 0.242 at −35 (director-fixed view). Sweep diagnostic: 0.294 at −15 (outline-chosen, end of sweep, not the reference view). Relative score: compare rounds, not assets |

## 2. System scorecard (from REVIEW_LOG.md)

| metric | skeleton v4 |
|---|---|
| Rounds to final | P0/1, P2/3, v4.3, v4.4 = 4 (+1 resend) |
| Director rulings per round needing judgment (beyond the checklist) | back-filled: 5 of 13; v4.4 live: 2 of 9 |
| Director/tool errors found by the builder | 3 (weighting example, chest joint name, impossible measurement wording) |
| Director errors found later by the director (dragon) | 2 (chain counts "from measurements"; "finger count = 4" in v1.1) |
| Rounds lost to a measurement error | 2 (short shins) |
| Builder visual "yes" contradicted by the director's render | 1 of 6 (scapula, one-sided view) |

| shadow run | agreement (light vs Opus) | missed gate failures | checkpoint graduated? |
|---|---|---|---|
| Dragon v1 P1 (Pengu first) | 16 / 18 = 89% | 1 (off-subject landmarks) + 1 design miss (rig vs clips) | no; re-test at the dragon P1b shadow |
| Dragon v1 P1b (Pengu first) | 11 / 18 = 61% | 1 (joints on the subject but off their feature) + 1 count error (5 spars, rigged 4) | no; re-test at the P1c shadow with feature_check |
| Dragon v1 P1c (Pengu first) | 16 / 16 = 100% | 0 | first clean pass; graduates if the next asset's P1 is clean first time |
| Dragon v1 P2 render review (Pengu first) | 10 / 12 = 83% | 1 form read (belly/legs) + the rig fan (shared with the director) | no; re-test at P2b with required close-ups |
| Dragon v1 P2b render review (Pengu first) | 8 / 11 = 73% | 1 (posed belly skinning sack) | no; re-test at P2c with posed close-ups + weights tool |
| Dragon v1 P2c render review (Pengu first) | 8 / 8 = 100% | 0 | first clean pass; next test: the P4 clip review |
| Dragon v1 P4 clip review (Pengu first) | 13 / 15 = 87% | 1 (floating rigid parts) | no; re-test at P4b |
| Dragon v1 P4b clip review (Pengu first) | 11 / 11 = 100% | 0 | final round; dragon delivered |

## 3. Graduation rules (per checkpoint)

1. **Shadow run.** On a new asset, the light model (Sonnet / Muse director) runs
   `director-review` on each STOP report FIRST and writes its rulings. Opus then
   reviews independently. Log agreement per ruling.
2. **Graduate a checkpoint** when, across one full asset: the light model's rulings
   agree with Opus's on ≥ 90% of items, it misses no gate failure, and its
   final asset scorecard is within 0.03 IoU of the Opus-directed result.
3. **Order:** measurement check (P1) first → render review (P2/3) → final review →
   directive writing last.
4. **Regression:** after any tool or skill change, rebuild the skeleton benchmark
   (refs + contract + template, no prior files) with the light model as director.
   Its scorecard must not drop below the last accepted one.


## Dragon v1 final scorecard (delivered `phase04b/dragon_v1.glb`, MD5 9530caf2279799b140d0071b75149073)
| metric | value |
|---|---|
| Side likeness IoU | 0.7787 (first build 0.7077) |
| Pose (end to end, Blender) | chains 0.0006 m, branch 0.098 m, fingers vs _0 0.005 m |
| Tris / budget | 34,784 / 35,000; 3.13 MB |
| Joints / materials | 77 / exactly 6 |
| Clips / morphs | 11 (flight_base + 10) / 2 (pulse_expand, pulse_contract) |
| Tool gates | eval PASS, validate 0/0, weights 0, contact 0/88 (signed), clips --own 0, Three.js 59/59 |
| Face | mouth blob ratio 0.96 (dark_iou diagnostic only: painted reference shadows) |
| Rounds to final | P1, P1b, P1c, P2, P2b, P2c, P4, P4b = 8 |
| Known gaps | scales as geometry/normal map (out of scope v1); RightWing* mirrored estimate; nostril not profile-readable |
