# Blue Dragon v1 — delivery

`dragon_v1.glb` (3,128,700 bytes, MD5 9530caf2279799b140d0071b75149073), glTF 2.0 binary for Three.js / WebGPU.

- +Y up, +Z forward, Left = +X, 1 unit = 1 m, origin at the chest. 6.0 m snout to tail tip, 11.96 m wingspan.
- 34,784 tris, 77 joints (1 skin), 6 materials (mat_body, mat_belly, mat_horn, mat_membrane [double-sided], mat_dark, emissive_eye + KHR_materials_emissive_strength).
- 11 clips, 30 fps, 120 BPM. Play `flight_base` at weight 1 (it folds the legs), and layer the others additively. `head_bob` and `head_roar` are mutually exclusive. Accent times are in each animation's `extras.accents_s`.
- 2 morph targets on the body: `pulse_expand` (+6%) and `pulse_contract` (−4%), default 0, for sub-bass.
- COLOR_0 is stored but not wired: r = part ID, g = distance from the chest, b = spanwise/tail 0→1.
- Sockets: `socket_mouth` (fire/VFX), `socket_tail_tip`.

Full clip table, layering rules and the timing note: `README.md`. Every check and how the asset scored: `SCORECARD_and_BENCHMARK.md`.

Timing note: every clip reads one frame (0.033 s) longer than its musical length because of how the exporter stamps frames (see README). The accent times in extras are the authorial beat times.
