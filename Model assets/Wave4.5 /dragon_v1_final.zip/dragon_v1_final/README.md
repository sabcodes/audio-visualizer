# Blue Dragon v1 — visualizer README (Phase 4)

Final file: `dragon_v1.glb` — 3,129,016 bytes, 34,784 tris, 77 joints,
6 materials, 11 animations, 2 morph targets. Validate: no errors, no
warnings. Eval (Wave 3): QA GATES PASSED.

## Axes, scale, origin

- +Y up, +Z forward, Left = +X, 1 unit = 1 m (glTF coordinates).
- Origin at the chest. Rest pose = flight T-pose (wings spread level,
  legs tucked by `flight_base`, neck/tail straight, mouth closed).
- Rest span (F2 tip to tip): 11.964 m. Snout to upper tail prong: 6.120 m.
- Sockets: `socket_mouth` at (0, 0, 2.627) on Head; `socket_tail_tip` at
  (0, 0.08, −3.477) on TailProngUpper (glTF coords, verified exact).

## Materials (exactly six)

`mat_body` #1F3F8F, `mat_belly` #9FB7D9, `mat_horn` #E2B64A,
`mat_membrane` #2E8FA6 (double-sided, the ONLY double-sided material),
`mat_dark` #141414, `emissive_eye` #7CF7FF (strength 1.0).

## COLOR_0 channels (skill §5; stored, not wired to a texture)

- r = part ID: body 0.0, neck/head 0.2, wings 0.4, tail 0.6, legs 0.8.
- g = distance from chest (0 at chest, 1 at the farthest part point).
- b = spanwise (wings) or tail 0→1; a = 0.

## Clips (30 fps, 120 BPM, 0.5 s = 1 beat)

Every clip except `flight_base` is an ADDITIVE layer on top of it.
Amplitudes below are the baked values, which already leave 40% headroom
for engine-side audio modulation.

| clip | len | loop | accents (s) | beats | layer | exclusive with | moves |
|---|---|---|---|---|---|---|---|
| flight_base | 1 frame | yes | — | 0 | base | — | Legs only, folded as in the Phase 2c likeness pose (forelegs back, hind legs tight). Nothing else. |
| wings_flap | 1.0 s | yes | 0.0, 0.5 | 2 | additive | — | WingRoot ±: +35° up at 0.5, −30° down at 0.0/1.0 (downstroke on the beat); Elbow/Hand lag ¼ cycle at 40%; finger _0 spread +5° on the downstroke, fold −10° on the upstroke. |
| wings_glide | 2.0 s | yes | 0.0, 1.0 | 4 | additive | — | Wings level (+5°); finger _1 ±3° wave F1→F5 (membrane ripple). |
| wings_burst | 0.5 s | no | 0.25 | 1 | additive | — | **Phase 4b: the FAN CLOSES** (not a unit sweep). Each finger _0 rotates in the wing plane toward F5's rest direction: F1 −70°, F2 −55°, F3 −40°, F4 −20°, F5 0° (all fingers end on F5's line, verified 0.0° in Blender and 70/55/40/20/0° sampled from the file), folded by 0.20 s, snap open 0.25–0.35 s with +5° overshoot scaled per finger by \|fold\|/70 (F1 5.0°, F2 3.93°, F3 2.86°, F4 1.43°, F5 0°), settled by 0.5. F5–flank membrane checked on the burst top contact sheet: no tear, no inversion. |
| head_bob | 0.5 s | yes | 0.0 | 1 | additive | head_roar | Head pitch −8° (nod down) on the beat, back by 0.5. |
| head_roar | 1.0 s | no | 0.25 | 2 | additive | head_bob | Neck1–6 pitch up 25° total, Head pitch +10°, Jaw open 25° at 0.25, hold to 0.6, closed by 1.0. Neck/head pitch follow the jaw envelope (0 at the ends). |
| neck_sway | 2.0 s | yes | 0.0, 1.0 | 4 | additive | — | Neck1–6 YAW only, travelling wave 6° per joint, 2-frame delay per joint; Head yaw −50% (counter). |
| tail_wave | 2.0 s | yes | 0.0, 1.0 | 4 | additive | — | Tail1–10 YAW, travelling wave root→tip, 3° → 10°, 2-frame delay per joint, seamless loop. |
| tail_whip | 0.5 s | no | 0.25 | 1 | additive | — | **Phase 4b: 25° TOTAL, tip-weighted, travelling** (not 25° per joint). Tail6 2°, Tail7 3°, Tail8 4°, Tail9 5°, Tail10 5°, TailTip 6°, each joint 1 frame after the one before (snap travels to the tip); tip peaks at 0.25, back by 0.5; prongs follow by hierarchy. Sampled from the file: 1.99/2.98/3.97/4.96/4.95/5.92°, peaks 1 frame apart, tip last. |
| body_bank_L | 2.0 s | no | 1.0 | 4 | additive | — | Chest ROLL +25° peak at 1.0, back to 0 by 2.0. Everything follows by hierarchy. Left wing dips. |
| body_bank_R | 2.0 s | no | 1.0 | 4 | additive | — | Chest ROLL −25° peak at 1.0, back to 0 by 2.0. Right wing dips. |

Animation extras on every clip: `{"loop", "accents_s", "bpm": 120,
"beats", "layer", "exclusive_with"}` as tabled above.

## Layering rules

- `flight_base` at weight 1; every other clip additive on top of it.
- `head_bob` and `head_roar` are MUTUALLY EXCLUSIVE (both pitch the
  Head) — never play them together.
- `head_roar` keys neck PITCH, `neck_sway` keys neck YAW: they may layer.
- `body_bank_*` keys only Chest roll; wings/legs/head/tail follow by
  hierarchy.
- Each clip animates ONLY its owners-table joints
  (`dragon_v1/config/clip_owners_dragon.json`); verified by
  `review_tools.py clips --own` (exit 0, 0 violations).

## Morph targets (body mesh only)

- `pulse_expand`: body vertices move outward from their local
  centreline by +6% of their distance to it (torso + neck + first 3 tail
  segments; fades to 0 over 0.3 m toward the head, the leg-root fillets,
  and Tail4). Max displacement 0.0307 m (chest).
- `pulse_contract`: the same field at −4%.
- Default weights 0. Spikes are separate rigid parts and do NOT follow
  the morph; their bases stay buried at +6% on the torso (see
  ASSUMPTIONS.md for the far-tail spike note).
- Names in `meshes[i].extras.targetNames`.

## Timing note (exporter convention, same as the skeleton)

The Blender glTF exporter stamps frame f at time f/30 s, so a clip
keyed on frames 1..N lands at 0.033..N/30 s: every duration reads one
frame (+0.033 s) longer than nominal (e.g. flap 1.033 s for 1.0 s), and
all clips share the same +1-frame offset. Accent times in extras are
the authorial beat times; relative alignment between clips is exact.
